package com.minhhieu.carinterior.controller;

import com.minhhieu.carinterior.model.database.ThuongHieu;
import com.minhhieu.carinterior.service.thuonghieu.ThuongHieuService;
import com.minhhieu.carinterior.service.user.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller
public class HomeController {

    @Autowired
    ThuongHieuService thuongHieuServ;

    @Autowired
    UsersService userSer;


    @RequestMapping(value = "/home", method = RequestMethod.GET)
    public String home(){
//        List<String > tenTH = new ArrayList<>();
//        for (ThuongHieu th : thuongHieuServ.getAllThuongHieu()){
//            tenTH.add(th.getTenthuonghieu());
//        }
//        map.addAttribute("thuonghieu",tenTH);

        return "pages/home";
    }

    @RequestMapping(value = "/loginabc", method = RequestMethod.POST)
    public String login(){
        return "login";
    }

}
