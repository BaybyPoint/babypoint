package com.minhhieu.carinterior.controller;

import com.minhhieu.carinterior.model.database.LoaiSanPham;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.service.loaisanpham.LoaiSanPhamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class LoaiSanPhamController {

    @Autowired
    private LoaiSanPhamService loaiSPSer ;

    @GetMapping("/everyone/loaisanpham")
    public List<LoaiSanPham> getAllLoaiSanPham(){
        return loaiSPSer.getAllLoaiSanPham();
    }

    @PostMapping("/manager/loaisanpham")
    public ResponseEntity<ErrorTemplate> createLoaiSanPham(@RequestParam("tenloaisanpham") String tenloaisanpham ){
        return loaiSPSer.createLoaiSanPham(tenloaisanpham);
    }

    @PutMapping("/manager/loaisanpham/{idloaisanpham}")
    public ResponseEntity<ErrorTemplate> setLoaiSanPham(@PathVariable("idloaisanpham") int idloaisanpham , @RequestParam("tenloaisanpham") String tenloaisanpham ){
        return loaiSPSer.setLoaiSanPham(idloaisanpham,tenloaisanpham);
    }

    @PatchMapping("/manager/loaisanpham/{idloaisanpham}")
    public ResponseEntity<ErrorTemplate> deleteLoaiSanPhamFake(@PathVariable("idloaisanpham") int idloaisanpham ){
        return loaiSPSer.removeLoaiSanPhamFake(idloaisanpham);
    }




}
