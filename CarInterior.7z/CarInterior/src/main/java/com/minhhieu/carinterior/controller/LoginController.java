package com.minhhieu.carinterior.controller;

import com.minhhieu.carinterior.service.jwt.JwtService;
import com.minhhieu.carinterior.service.user.UsersService;
import javafx.geometry.Pos;
import org.apache.tomcat.util.http.parser.Authorization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.GeneratedValue;

@RestController
public class LoginController {

    @Autowired
    UsersService userSer ;



}
