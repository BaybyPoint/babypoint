package com.minhhieu.carinterior.controller;

import com.minhhieu.carinterior.model.database.NhaCungCap;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.service.nhacungcap.NhaCungCapSer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class NhaCungCapController {

    @Autowired
    NhaCungCapSer nhaCC ;

    @GetMapping("/manager/nhacungcap")
    public List<NhaCungCap> getAllNhaCungCap(){
        return nhaCC.getAllNhaCungCap();
    }

    @PutMapping("/manager/nhacungcap/{idnhacungcap}")
    public ResponseEntity<ErrorTemplate> setNhaCungCap(@PathVariable("idnhacungcap") int idnhacungcap, @RequestParam("tennhacungcap") String tennhacungcap ){
        return nhaCC.setNhaCungCap(idnhacungcap, tennhacungcap);
    }



}
