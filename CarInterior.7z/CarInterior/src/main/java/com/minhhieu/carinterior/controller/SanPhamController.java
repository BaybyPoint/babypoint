package com.minhhieu.carinterior.controller;

import com.minhhieu.carinterior.model.database.SanPham;
import com.minhhieu.carinterior.model.request.SanPhamCreateRequest;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.model.response.sanpham_information.SanPhamInformation;
import com.minhhieu.carinterior.service.sanpham.SanPhamService;
import com.minhhieu.carinterior.service.sanpham_information.SanPhamInformationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class SanPhamController {

    @Autowired
    private SanPhamInformationService sanPhamISer;

    @Autowired
    private SanPhamService sanPhamSer;


    // lấy những bản ghi có trạng thái chưa xóa
    @GetMapping("/everyone/sanphams")
    public List<SanPhamInformation> getSanPhamInformation(){
        return sanPhamISer.getSanPhamInformation();
    }

    // lấy những bản ghi có trạng thái đã xóa
    @GetMapping("/manager/sanphams")
    public List<SanPhamInformation> getSanPhamInformationDeleted(){
        return sanPhamISer.getSanPhamInformationDeleted();
    }

    // tạo bản ghi mới
    @PostMapping("/manager/sanphams")
    public ResponseEntity<ErrorTemplate> createSanPham(@RequestParam("tensanpham") String tensanpham, @RequestParam("idloaisanpham") int idloaisanpham,
                                                       @RequestParam("dongia") int dongia, @RequestParam("thongsokithuat") String thongsokithuat,
                                                       @RequestParam("mota") String mota, @RequestParam("video") String video, @RequestParam("soluong") int soluong,
                                                       @RequestParam("idnhacungcap") int idnhacungcap, @RequestParam("idbaohanh") int idbaohanh,
                                                       @RequestParam("idthuonghieu") int idthuonghieu, @RequestParam("idmau") int idmau, @RequestParam("anh") String anh){
        SanPhamCreateRequest request = new SanPhamCreateRequest(tensanpham, thongsokithuat, mota, video, anh,idloaisanpham,soluong,dongia,idnhacungcap,idbaohanh,idthuonghieu,idmau);
        if(sanPhamSer.createSanPham(request)){
            return new ResponseEntity<>(HttpStatus.OK);
        }else
            return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !", "Kiểm tra lại mạng !"),HttpStatus.BAD_REQUEST);
    }

    // sửa bản ghi
    @PutMapping("/manager/sanphams/{idsanpham}")
    public ResponseEntity<ErrorTemplate> setSanPham(@PathVariable("idsanpham") int idsanpham,@RequestParam("tensanpham") String tensanpham, @RequestParam("idloaisanpham") int idloaisanpham,
                                                    @RequestParam("dongia") int dongia, @RequestParam("thongsokithuat") String thongsokithuat,
                                                    @RequestParam("mota") String mota, @RequestParam("video") String video, @RequestParam("soluong") int soluong,
                                                    @RequestParam("idnhacungcap") int idnhacungcap, @RequestParam("idbaohanh") int idbaohanh,
                                                    @RequestParam("idthuonghieu") int idthuonghieu, @RequestParam("idmau") int idmau, @RequestParam("anh") String anh){
        SanPhamCreateRequest request = new SanPhamCreateRequest(tensanpham, thongsokithuat, mota, video, anh,idloaisanpham,soluong,dongia,idnhacungcap,idbaohanh,idthuonghieu,idmau);
        return sanPhamSer.setSanPham(idsanpham, request);
    }

    // xóa hẳn bản ghi
    @DeleteMapping("/admin/sanphams/{idsanpham}")
    public ResponseEntity<ErrorTemplate> removeSanPhamReal(@PathVariable("idsanpham") int idsanpham){
        return sanPhamSer.deleteSanPhamReal(idsanpham);
    }

    // đổi trạng thái
    @PatchMapping ("/manager/sanphams/{idsanpham}")
    public ResponseEntity<ErrorTemplate> removeSanPhamFake(@PathVariable("idsanpham") int idsanpham){
        return sanPhamSer.deleteSanPhamFake(idsanpham);
    }

    // khôi phục những bản ghi ở trạng thái đã xóa
    @PatchMapping("/manager/sanpham/{idsanpham}/restore")
    public ResponseEntity<ErrorTemplate> restoreSanPhamFake(@PathVariable("idsanpham") int idsanpham){
        return sanPhamSer.restoreSanPhamFake(idsanpham);
    }

}
