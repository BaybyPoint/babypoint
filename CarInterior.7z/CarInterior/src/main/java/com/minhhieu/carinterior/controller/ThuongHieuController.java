package com.minhhieu.carinterior.controller;

import com.minhhieu.carinterior.model.database.ThuongHieu;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.service.thuonghieu.ThuongHieuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ThuongHieuController {

    @Autowired
    private ThuongHieuService thuongHieuSer ;

    @GetMapping("/everyone/thuonghieus")
    public List<ThuongHieu> getThuongHieu(){
        return thuongHieuSer.getAllThuongHieu();
    }

    @PostMapping("/manager/thuonghieus")
    public ResponseEntity<ErrorTemplate> createThuongHieu(@RequestParam("tenthuonghieu") String tenthuonghieu){
        return thuongHieuSer.createThuongHieu(tenthuonghieu);
    }

    @PutMapping("/manager/thuonghieus/{idthuonghieu}")
    public ResponseEntity<ErrorTemplate> setThuongHieu(@PathVariable("idthuonghieu") int idthuonghieu,@RequestParam("tenthuonghieu") String tenthuonghieu){
        return thuongHieuSer.setThuongHieu(idthuonghieu,tenthuonghieu);
    }

    @DeleteMapping("/manager/thuonghieus/{idthuonghieu}")
    public ResponseEntity<ErrorTemplate> removeThuongHieu(@PathVariable("idthuonghieu") int idthuonghieu){
        return thuongHieuSer.removeThuongHieu(idthuonghieu);
    }
}
