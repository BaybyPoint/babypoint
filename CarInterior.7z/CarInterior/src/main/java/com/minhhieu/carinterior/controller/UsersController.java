package com.minhhieu.carinterior.controller;

import com.minhhieu.carinterior.model.request.UserRegisterRequest;
import com.minhhieu.carinterior.model.response.PageableResponse;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.model.response.user_profile.UserProfileResNoPass;
import com.minhhieu.carinterior.model.response.user_profile.UserProfileResponse;
import com.minhhieu.carinterior.service.userprofile.UserProfileResNoPassService;
import com.minhhieu.carinterior.service.userprofile.UserProfileService;
import com.minhhieu.carinterior.service.profile.ProfileService;
import com.minhhieu.carinterior.model.request.Condition;
import com.minhhieu.carinterior.service.user.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class UsersController {

    @Autowired
    private UsersService usersService;

    @Autowired
    private ProfileService profileService;

    @Autowired
    private UserProfileResNoPassService UPNoPassSer;

    @Autowired
    private UserProfileService UPSer ;

    @RequestMapping(value = "/manager/user1/{iduser}", method = RequestMethod.GET)
    public UserProfileResponse getOneUserProfile(@PathVariable("iduser")int iduser){
        return UPSer.getUserProfileResponse(iduser);
    }

    @RequestMapping(value = "/everyone/user1/{iduser}", method = RequestMethod.GET)
    public UserProfileResNoPass getOneUserProfileNoPass(@PathVariable("iduser")int iduser){
        return UPNoPassSer.findOneUserProfileResNoPass(iduser);
    }

    @RequestMapping(value = "/manager/user" , method = RequestMethod.GET)
    public PageableResponse getDataUserLimit(@RequestParam(value = "condition") Condition condition, @RequestParam(value = "page") int page, @RequestParam(value = "pagesize", defaultValue = "5") int pagesize){
        return usersService.getDataUserLimit(condition, page, pagesize);
    }

    @RequestMapping(value = "/everyone/user/register", method = RequestMethod.POST)
    public ResponseEntity<ErrorTemplate> createUserCustommer(@RequestParam(value = "username") String username, @RequestParam(value = "password") String password,
                                                    @RequestParam(value = "email") String email, @RequestParam(value = "age") int age,
                                                    @RequestParam(value = "address") String address,
                                                    @RequestParam(value = "avatar") String avatar) {
        UserRegisterRequest request = new UserRegisterRequest(username,password, email,age, address, avatar);
        if(profileService.createUserProfile(3,request)){
            return new ResponseEntity<>(new ErrorTemplate(200, "Thành Công !", "Đã tạo thành công !"), HttpStatus.OK);
        }else
            return new ResponseEntity<>(new ErrorTemplate(404, "Thất bại !", "Trùng username hoặc password !"),HttpStatus.BAD_REQUEST);
    }

    @RequestMapping(value = "/admin/user/register", method = RequestMethod.POST)
    public ResponseEntity<ErrorTemplate> createUserAdmin(@RequestParam(value = "idrole") int idrole,@RequestParam(value = "username") String username, @RequestParam(value = "password") String password,
                                                    @RequestParam(value = "email") String email, @RequestParam(value = "age") int age,
                                                    @RequestParam(value = "address") String address,
                                                    @RequestParam(value = "avatar") String avatar) {
        UserRegisterRequest request = new UserRegisterRequest(username,password, email,age, address, avatar);
        if(profileService.createUserProfile(idrole, request)){
            return new ResponseEntity<>(new ErrorTemplate(200, "Thành Công !", "Đã tạo thành công !"), HttpStatus.OK);
        }else
            return new ResponseEntity<>(new ErrorTemplate(404, "Thất bại !", "Trùng username hoặc password !"),HttpStatus.BAD_REQUEST);
    }

    @RequestMapping(value = "/manager/user/{iduser}", method = RequestMethod.DELETE)
    public ResponseEntity<ErrorTemplate> deleteUserById(@PathVariable("iduser") int iduser){
        if (usersService.deleteUserById(iduser)){
            return new ResponseEntity(HttpStatus.OK);
        }return new ResponseEntity(new ErrorTemplate(404, "Thất bại !", " Lỗi không xác định !"),HttpStatus.BAD_REQUEST);
    }




    @RequestMapping(value = "/everyone/login1" , method = RequestMethod.POST)
    public String login(@RequestParam("username") String username, @RequestParam("password") String password){
        return usersService.getJwp(username, password);
    }



}
