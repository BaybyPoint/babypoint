package com.minhhieu.carinterior.controller.security;
import com.minhhieu.carinterior.model.database.KhuyenMai;
import com.minhhieu.carinterior.model.request.KhuyenMai_ChiTiet;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.service.khuyenmai.KhuyenMaiService;
import com.minhhieu.carinterior.service.khuyenmai_chitiet.KhuyenMai_ChitietSerImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class KhuyenMaiController {

    @Autowired
    private KhuyenMai_ChitietSerImp km_CTSer ;

    @Autowired
    private KhuyenMaiService kMaiSer ;

    @GetMapping("/manager/khuyenmai")
    public List<KhuyenMai_ChiTiet> getInformationKhuyenMai()
    {
        return km_CTSer.getInformationKhuyenMai();
    }

    @GetMapping("/manager/khuyenmai/active")
    public List<KhuyenMai_ChiTiet> getKhuyenMaiStatusOne()
    {
        return km_CTSer.getInformationKhuyenMai();
    }

    @PostMapping("/manager/khuyenmai")
    public ResponseEntity<ErrorTemplate> createNewKhuyenMai( @RequestBody KhuyenMai khuyenMai){
        return kMaiSer.createNewKhuyenMai(khuyenMai);
    }

    @PutMapping("/manager/khuyenmai")
    public ResponseEntity<ErrorTemplate> setKhuyenMai( @RequestBody KhuyenMai khuyenMai){
        return kMaiSer.setKhuyenMai(khuyenMai);
    }

    @DeleteMapping("/manager/khuyenmai/{idkhuyenmai}")
    public ResponseEntity<ErrorTemplate> deleteKhuyenMai(@PathVariable("idkhuyenmai") int idkhuyenmai){
        return kMaiSer.deleteKhuyenMai(idkhuyenmai);
    }




}
