package com.minhhieu.carinterior.controller.security.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class RestAuthenticationEntryPoint implements AuthenticationEntryPoint {
    @Override
    public void commence(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AuthenticationException e) throws IOException, ServletException {
        httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        String errStr = "";
        try {
            ObjectMapper mapper = new ObjectMapper();
            ErrorTemplate err = new ErrorTemplate(404, "Thất bại !", " Có vấn đề với mã xác thực !");
            errStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(err);
        }catch (IOException ex){
        }
        httpServletResponse.getWriter().write(errStr);
    }
}
