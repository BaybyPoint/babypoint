package com.minhhieu.carinterior.model.database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "BAOHANH")
public class BaoHanh {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idbaohanh ;
    private String thoigianbaohanh;

    public BaoHanh(String thoigianbaohanh) {
        this.thoigianbaohanh = thoigianbaohanh;
    }

    public int getIdbaohanh() {
        return idbaohanh;
    }

    public void setIdbaohanh(int idbaohanh) {
        this.idbaohanh = idbaohanh;
    }

    public String getThoigianbaohanh() {
        return thoigianbaohanh;
    }

    public void setThoigianbaohanh(String thoigianbaohanh) {
        this.thoigianbaohanh = thoigianbaohanh;
    }

    public BaoHanh() {
    }
}
