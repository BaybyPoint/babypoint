package com.minhhieu.carinterior.model.database;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "CHITIETKHUYENMAI")
public class ChiTietKhuyenMai {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idchitietkhuyenmai ;
    private String hinhthuc, ngaybatdau, ngayketthuc ;
    private int trangthai ;
    private float toantu ;

    public ChiTietKhuyenMai() {
    }

    public float getToantu() {
        return toantu;
    }

    public void setToantu(float toantu) {
        this.toantu = toantu;
    }

    public ChiTietKhuyenMai(String hinhthuc, String ngaybatdau, String ngayketthuc, int trangthai, float toantu) {
        this.hinhthuc = hinhthuc;
        this.ngaybatdau = ngaybatdau;
        this.ngayketthuc = ngayketthuc;
        this.trangthai = trangthai;
        this.toantu = toantu;
    }

    public int getIdchitietkhuyenmai() {
        return idchitietkhuyenmai;
    }

    public void setIdchitietkhuyenmai(int idchitietkhuyenmai) {
        this.idchitietkhuyenmai = idchitietkhuyenmai;
    }

    public String getHinhthuc() {
        return hinhthuc;
    }

    public void setHinhthuc(String hinhthuc) {
        this.hinhthuc = hinhthuc;
    }

    public String getNgaybatdau() {
        return ngaybatdau;
    }

    public void setNgaybatdau(String ngaybatdau) {
        this.ngaybatdau = ngaybatdau;
    }

    public String getNgayketthuc() {
        return ngayketthuc;
    }

    public void setNgayketthuc(String ngayketthuc) {
        this.ngayketthuc = ngayketthuc;
    }

    public int getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(int trangthai) {
        this.trangthai = trangthai;
    }

    public ChiTietKhuyenMai(String hinhthuc, String ngaybatdau, String ngayketthuc, int trangthai) {
        this.hinhthuc = hinhthuc;
        this.ngaybatdau = ngaybatdau;
        this.ngayketthuc = ngayketthuc;
        this.trangthai = trangthai;
    }
}
