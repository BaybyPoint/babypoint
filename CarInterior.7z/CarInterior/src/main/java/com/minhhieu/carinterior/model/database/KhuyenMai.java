package com.minhhieu.carinterior.model.database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "KHUYENMAI")
public class KhuyenMai {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idkhuyenmai ;
    private String tenkhuyenmai ;
    private int idchitietkhuyenmai, trangthai ;

    public KhuyenMai() {
    }

    public int getIdchitietkhuyenmai() {
        return idchitietkhuyenmai;
    }

    public int getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(int trangthai) {
        this.trangthai = trangthai;
    }

    public KhuyenMai(String tenkhuyenmai, int idchitietkhuyenmai, int trangthai) {
        this.tenkhuyenmai = tenkhuyenmai;
        this.idchitietkhuyenmai = idchitietkhuyenmai;
        this.trangthai = trangthai;
    }

    public void setIdchitietkhuyenmai(int idchitietkhuyenmai) {
        this.idchitietkhuyenmai = idchitietkhuyenmai;
    }

    public KhuyenMai(String tenkhuyenmai, int idchitietkhuyenmai) {
        this.tenkhuyenmai = tenkhuyenmai;
        this.idchitietkhuyenmai = idchitietkhuyenmai;
    }

    public int getIdkhuyenmai() {
        return idkhuyenmai;
    }

    public void setIdkhuyenmai(int idkhuyenmai) {
        this.idkhuyenmai = idkhuyenmai;
    }

    public String getTenkhuyenmai() {
        return tenkhuyenmai;
    }

    public void setTenkhuyenmai(String tenkhuyenmai) {
        this.tenkhuyenmai = tenkhuyenmai;
    }

    public KhuyenMai(String tenkhuyenmai) {
        this.tenkhuyenmai = tenkhuyenmai;
    }
}
