package com.minhhieu.carinterior.model.database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name= "LOAISANPHAM")
public class LoaiSanPham {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idloaisanpham;

    private String tenloaisanpham;
    private int trangthai;

    public LoaiSanPham(String tenloaisanpham, int trangthai) {
        this.tenloaisanpham = tenloaisanpham;
        this.trangthai = trangthai;
    }

    public LoaiSanPham(String tenloaisanpham) {
        this.tenloaisanpham = tenloaisanpham;
    }

    public LoaiSanPham() {
    }

    public int getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(int trangthai) {
        this.trangthai = trangthai;
    }

    public int getIdloaisanpham() {
        return idloaisanpham;
    }

    public void setIdloaisanpham(int idloaisanpham) {
        this.idloaisanpham = idloaisanpham;
    }

    public String getTenloaisanpham() {
        return tenloaisanpham;
    }

    public void setTenloaisanpham(String tenloaisanpham) {
        this.tenloaisanpham = tenloaisanpham;
    }
}
