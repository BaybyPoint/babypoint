package com.minhhieu.carinterior.model.database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "MAUSANPHAM")
public class MauSanPham {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idmau ;

    private String tenmau ;

    public MauSanPham(String tenmau) {
        this.tenmau = tenmau;
    }

    public int getIdmau() {
        return idmau;
    }

    public void setIdmau(int idmau) {
        this.idmau = idmau;
    }

    public String getTenmau() {
        return tenmau;
    }

    public void setTenmau(String tenmau) {
        this.tenmau = tenmau;
    }

    public MauSanPham() {
    }
}
