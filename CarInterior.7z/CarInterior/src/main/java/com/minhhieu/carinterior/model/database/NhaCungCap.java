package com.minhhieu.carinterior.model.database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "NHACUNGCAP")
public class NhaCungCap {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idnhacungcap;

    private String tennhacungcap ;

    public NhaCungCap(String tennhacungcap) {
        this.tennhacungcap = tennhacungcap;
    }

    public int getIdnhacungcap() {
        return idnhacungcap;
    }

    public void setIdnhacungcap(int idnhacungcap) {
        this.idnhacungcap = idnhacungcap;
    }

    public String getTennhacungcap() {
        return tennhacungcap;
    }

    public void setTennhacungcap(String tennhacungcap) {
        this.tennhacungcap = tennhacungcap;
    }

    public NhaCungCap() {
    }
}
