package com.minhhieu.carinterior.model.database;

import javax.persistence.*;
import java.util.List;

@Entity(name = "ROLES")
public class Roles  {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idrole;
    private String role ;

    @ManyToMany(fetch = FetchType.EAGER, mappedBy = "roles")
    private List<Users> users;

    public List<Users> getUsers() {
        return users;
    }

    public void setUsers(List<Users> users) {
        this.users = users;
    }

    public Roles() {
    }

    public int getIdrole() {
        return idrole;
    }

    public void setIdrole(int idrole) {
        this.idrole = idrole;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Roles(String role) {
        this.role = role;
    }
}
