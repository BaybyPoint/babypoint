package com.minhhieu.carinterior.model.database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "SANPHAM")
public class SanPham {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idsanpham;

    private int idloaisanpham, dongia, soluong, idnhacungcap, idbaohanh, idthuonghieu, idmau, trangthai ;
    private String tensanpham,  thongsokithuat, mota, video, anh;

    public SanPham(int idloaisanpham, int dongia, int soluong, int idnhacungcap, int idbaohanh, int idthuonghieu, int idmau, String tensanpham, String thongsokithuat, String mota, String video, String anh, int trangthai) {
        this.idloaisanpham = idloaisanpham;
        this.dongia = dongia;
        this.soluong = soluong;
        this.idnhacungcap = idnhacungcap;
        this.idbaohanh = idbaohanh;
        this.idthuonghieu = idthuonghieu;
        this.idmau = idmau;
        this.tensanpham = tensanpham;
        this.thongsokithuat = thongsokithuat;
        this.mota = mota;
        this.video = video;
        this.anh = anh;
        this.trangthai = trangthai;
    }

    public int getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(int trangthai) {
        this.trangthai = trangthai;
    }

    public int getIdsanpham() {
        return idsanpham;
    }

    public void setIdsanpham(int idsanpham) {
        this.idsanpham = idsanpham;
    }

    public int getIdloaisanpham() {
        return idloaisanpham;
    }

    public void setIdloaisanpham(int idloaisanpham) {
        this.idloaisanpham = idloaisanpham;
    }

    public int getDongia() {
        return dongia;
    }

    public void setDongia(int dongia) {
        this.dongia = dongia;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public int getIdnhacungcap() {
        return idnhacungcap;
    }

    public void setIdnhacungcap(int idnhacungcap) {
        this.idnhacungcap = idnhacungcap;
    }

    public int getIdbaohanh() {
        return idbaohanh;
    }

    public void setIdbaohanh(int idbaohanh) {
        this.idbaohanh = idbaohanh;
    }

    public int getIdthuonghieu() {
        return idthuonghieu;
    }

    public void setIdthuonghieu(int idthuonghieu) {
        this.idthuonghieu = idthuonghieu;
    }

    public int getIdmau() {
        return idmau;
    }

    public void setIdmau(int idmau) {
        this.idmau = idmau;
    }

    public String getTensanpham() {
        return tensanpham;
    }

    public void setTensanpham(String tensanpham) {
        this.tensanpham = tensanpham;
    }

    public String getThongsokithuat() {
        return thongsokithuat;
    }

    public void setThongsokithuat(String thongsokithuat) {
        this.thongsokithuat = thongsokithuat;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public String getAnh() {
        return anh;
    }

    public void setAnh(String anh) {
        this.anh = anh;
    }

    public SanPham() {
    }
}
