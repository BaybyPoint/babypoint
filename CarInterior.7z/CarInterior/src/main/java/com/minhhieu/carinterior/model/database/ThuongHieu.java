package com.minhhieu.carinterior.model.database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "THUONGHIEU")
public class ThuongHieu {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idthuonghieu;

    private String tenthuonghieu;

    public ThuongHieu() {
    }

    public int getIdthuonghieu() {
        return idthuonghieu;
    }

    public void setIdthuonghieu(int idthuonghieu) {
        this.idthuonghieu = idthuonghieu;
    }

    public String getTenthuonghieu() {
        return tenthuonghieu;
    }

    public void setTenthuonghieu(String tenthuonghieu) {
        this.tenthuonghieu = tenthuonghieu;
    }

    public ThuongHieu(int idthuonghieu, String tenthuonghieu) {
        this.idthuonghieu = idthuonghieu;
        this.tenthuonghieu = tenthuonghieu;
    }
}
