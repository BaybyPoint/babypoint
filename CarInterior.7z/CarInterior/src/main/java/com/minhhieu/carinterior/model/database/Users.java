package com.minhhieu.carinterior.model.database;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = { "roles", "authorities" })
@Entity(name = "USERS")
public class Users  {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int iduser;

    private String username, password, email ;

    private long idprofile;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "USERS_ROLES",
            joinColumns = { @JoinColumn(name = "iduser", nullable = false) },
            inverseJoinColumns = { @JoinColumn(name = "idrole", nullable = false) })
    private List<Roles> roles;


    public List<GrantedAuthority> getAuthorities() {
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        for (Roles role : roles) {
            authorities.add(new SimpleGrantedAuthority(role.getRole()));
        }
        return authorities;
    }


    public Users(String username, String password, String email, long idprofile, List<Roles> roles) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.idprofile = idprofile;
        this.roles = roles;
    }

    public List<Roles> getRoles() {
        return roles;
    }

    public void setRoles(List<Roles> roles) {
        this.roles = roles;
    }

    public Users(String username, String password, String email, Long idprofile) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.idprofile = idprofile;
    }

    public long getIdprofile() {
        return idprofile;
    }

    public void setIdprofile(long idprofile) {
        this.idprofile = idprofile;
    }

    public Users(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }

    public Users() {
    }

    public Users(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


}
