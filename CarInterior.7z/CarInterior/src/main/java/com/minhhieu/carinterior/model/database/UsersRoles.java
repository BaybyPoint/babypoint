package com.minhhieu.carinterior.model.database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "USERS_ROLES")
public class UsersRoles {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idusersroles ;
    private int iduser , idrole;

    public int getIdusersroles() {
        return idusersroles;
    }

    public void setIdusersroles(int idusersroles) {
        this.idusersroles = idusersroles;
    }

    public UsersRoles() {
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public int getIdrole() {
        return idrole;
    }

    public void setIdrole(int idrole) {
        this.idrole = idrole;
    }

    public UsersRoles(int iduser, int idrole) {
        this.iduser = iduser;
        this.idrole = idrole;
    }
}
