package com.minhhieu.carinterior.model.database;

public class UsersTest {
    private String username, password ;

    public UsersTest() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UsersTest(String username, String password) {
        this.username = username;
        this.password = password;
    }
}
