package com.minhhieu.carinterior.model.request;

public enum  Condition {
    email, username ;
}
