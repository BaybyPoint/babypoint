package com.minhhieu.carinterior.model.request;

import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Immutable
public class KhuyenMai_ChiTiet {

    @Id
    private int idkhuyenmai ;
    private String tenkhuyenmai, hinhthuc, ngaybatdau, ngayketthuc ;
    private int idchitietkhuyenmai , trangthai, toantu ;

    public KhuyenMai_ChiTiet(int idkhuyenmai, String tenkhuyenmai, String hinhthuc, String ngaybatdau, String ngayketthuc, int idchitietkhuyenmai, int trangthai, int toantu) {
        this.idkhuyenmai = idkhuyenmai;
        this.tenkhuyenmai = tenkhuyenmai;
        this.hinhthuc = hinhthuc;
        this.ngaybatdau = ngaybatdau;
        this.ngayketthuc = ngayketthuc;
        this.idchitietkhuyenmai = idchitietkhuyenmai;
        this.trangthai = trangthai;
        this.toantu = toantu;
    }

    public KhuyenMai_ChiTiet() {
    }

    public int getIdkhuyenmai() {
        return idkhuyenmai;
    }

    public void setIdkhuyenmai(int idkhuyenmai) {
        this.idkhuyenmai = idkhuyenmai;
    }

    public String getTenkhuyenmai() {
        return tenkhuyenmai;
    }

    public void setTenkhuyenmai(String tenkhuyenmai) {
        this.tenkhuyenmai = tenkhuyenmai;
    }

    public String getHinhthuc() {
        return hinhthuc;
    }

    public void setHinhthuc(String hinhthuc) {
        this.hinhthuc = hinhthuc;
    }

    public String getNgaybatdau() {
        return ngaybatdau;
    }

    public void setNgaybatdau(String ngaybatdau) {
        this.ngaybatdau = ngaybatdau;
    }

    public String getNgayketthuc() {
        return ngayketthuc;
    }

    public void setNgayketthuc(String ngayketthuc) {
        this.ngayketthuc = ngayketthuc;
    }

    public int getIdchitietkhuyenmai() {
        return idchitietkhuyenmai;
    }

    public void setIdchitietkhuyenmai(int idchitietkhuyenmai) {
        this.idchitietkhuyenmai = idchitietkhuyenmai;
    }

    public int getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(int trangthai) {
        this.trangthai = trangthai;
    }

    public int getToantu() {
        return toantu;
    }

    public void setToantu(int toantu) {
        this.toantu = toantu;
    }
}
