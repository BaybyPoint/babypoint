package com.minhhieu.carinterior.model.request;

public class SanPhamCreateRequest {
    private String tensanpham, thongsokithuat, mota, video, anh ;
    private int idloaisanpham, soluong, dongia, idnhacungcap, idbaohanh, idthuonghieu, idmau ;

    public SanPhamCreateRequest(String tensanpham, String thongsokithuat, String mota, String video, String anh, int idloaisanpham, int soluong, int dongia, int idnhacungcap, int idbaohanh, int idthuonghieu, int idmau) {
        this.tensanpham = tensanpham;
        this.thongsokithuat = thongsokithuat;
        this.mota = mota;
        this.video = video;
        this.anh = anh;
        this.idloaisanpham = idloaisanpham;
        this.soluong = soluong;
        this.dongia = dongia;
        this.idnhacungcap = idnhacungcap;
        this.idbaohanh = idbaohanh;
        this.idthuonghieu = idthuonghieu;
        this.idmau = idmau;
    }

    public SanPhamCreateRequest() {
    }

    public String getTensanpham() {
        return tensanpham;
    }

    public void setTensanpham(String tensanpham) {
        this.tensanpham = tensanpham;
    }

    public String getThongsokithuat() {
        return thongsokithuat;
    }

    public void setThongsokithuat(String thongsokithuat) {
        this.thongsokithuat = thongsokithuat;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public String getAnh() {
        return anh;
    }

    public void setAnh(String anh) {
        this.anh = anh;
    }

    public int getIdloaisanpham() {
        return idloaisanpham;
    }

    public void setIdloaisanpham(int idloaisanpham) {
        this.idloaisanpham = idloaisanpham;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public int getDongia() {
        return dongia;
    }

    public void setDongia(int dongia) {
        this.dongia = dongia;
    }

    public int getIdnhacungcap() {
        return idnhacungcap;
    }

    public void setIdnhacungcap(int idnhacungcap) {
        this.idnhacungcap = idnhacungcap;
    }

    public int getIdbaohanh() {
        return idbaohanh;
    }

    public void setIdbaohanh(int idbaohanh) {
        this.idbaohanh = idbaohanh;
    }

    public int getIdthuonghieu() {
        return idthuonghieu;
    }

    public void setIdthuonghieu(int idthuonghieu) {
        this.idthuonghieu = idthuonghieu;
    }

    public int getIdmau() {
        return idmau;
    }

    public void setIdmau(int idmau) {
        this.idmau = idmau;
    }
}
