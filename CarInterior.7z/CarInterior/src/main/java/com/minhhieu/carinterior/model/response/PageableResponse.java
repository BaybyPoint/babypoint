package com.minhhieu.carinterior.model.response;

import com.minhhieu.carinterior.model.database.Users;

import java.util.List;

public class PageableResponse {
    private int pageSize;
    private int currentPage;
    private double totalPages;
    List<Users> lstUsers;

    public PageableResponse() {
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public double getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(double totalPages) {
        this.totalPages = totalPages;
    }

    public List<Users> getLstUsers() {
        return lstUsers;
    }

    public void setLstUsers(List<Users> lstUser) {
        this.lstUsers = lstUser;
    }

    public PageableResponse(int pageSize, int currentPage, double totalPages, List<Users> lstUser) {
        this.pageSize = pageSize;
        this.currentPage = currentPage;
        this.totalPages = totalPages;
        this.lstUsers = lstUser;
    }

}
