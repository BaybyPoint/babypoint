package com.minhhieu.carinterior.model.response.errors;

public class ErrorTemplate {
    private int error_code ;
    private String error_name, error_cause ;

    public ErrorTemplate(int error_code, String error_name, String error_cause) {
        this.error_code = error_code;
        this.error_name = error_name;
        this.error_cause = error_cause;
    }

    public int getError_code() {
        return error_code;
    }

    public void setError_code(int error_code) {
        this.error_code = error_code;
    }

    public String getError_name() {
        return error_name;
    }

    public void setError_name(String error_name) {
        this.error_name = error_name;
    }

    public String getError_cause() {
        return error_cause;
    }

    public void setError_cause(String error_cause) {
        this.error_cause = error_cause;
    }
}
