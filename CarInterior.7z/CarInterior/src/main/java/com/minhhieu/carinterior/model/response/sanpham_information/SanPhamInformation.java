package com.minhhieu.carinterior.model.response.sanpham_information;

import jdk.nashorn.internal.ir.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Immutable
public class SanPhamInformation {
    @Id
    private int idsanpham ;

    private String tensanpham, tenloaisanpham, thongsokithuat,mota,video,tennhacungcap,thoigianbaohanh,tenthuonghieu,tenmau,anh;
    private int dongia,soluong ;

    public SanPhamInformation(int idsanpham, String tensanpham, String tenloaisanpham, String thongsokithuat, String mota, String video, String tennhacungcap, String thoigianbaohanh, String tenthuonghieu, String tenmau, String anh, int dongia, int soluong) {
        this.idsanpham = idsanpham;
        this.tensanpham = tensanpham;
        this.tenloaisanpham = tenloaisanpham;
        this.thongsokithuat = thongsokithuat;
        this.mota = mota;
        this.video = video;
        this.tennhacungcap = tennhacungcap;
        this.thoigianbaohanh = thoigianbaohanh;
        this.tenthuonghieu = tenthuonghieu;
        this.tenmau = tenmau;
        this.anh = anh;
        this.dongia = dongia;
        this.soluong = soluong;
    }

    public SanPhamInformation() {
    }

    public int getIdsanpham() {
        return idsanpham;
    }

    public void setIdsanpham(int idsanpham) {
        this.idsanpham = idsanpham;
    }

    public String getTensanpham() {
        return tensanpham;
    }

    public void setTensanpham(String tensanpham) {
        this.tensanpham = tensanpham;
    }

    public String getTenloaisanpham() {
        return tenloaisanpham;
    }

    public void setTenloaisanpham(String tenloaisanpham) {
        this.tenloaisanpham = tenloaisanpham;
    }

    public String getThongsokithuat() {
        return thongsokithuat;
    }

    public void setThongsokithuat(String thongsokithuat) {
        this.thongsokithuat = thongsokithuat;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public String getTennhacungcap() {
        return tennhacungcap;
    }

    public void setTennhacungcap(String tennhacungcap) {
        this.tennhacungcap = tennhacungcap;
    }

    public String getThoigianbaohanh() {
        return thoigianbaohanh;
    }

    public void setThoigianbaohanh(String thoigianbaohanh) {
        this.thoigianbaohanh = thoigianbaohanh;
    }

    public String getTenthuonghieu() {
        return tenthuonghieu;
    }

    public void setTenthuonghieu(String tenthuonghieu) {
        this.tenthuonghieu = tenthuonghieu;
    }

    public String getTenmau() {
        return tenmau;
    }

    public void setTenmau(String tenmau) {
        this.tenmau = tenmau;
    }

    public String getAnh() {
        return anh;
    }

    public void setAnh(String anh) {
        this.anh = anh;
    }

    public int getDongia() {
        return dongia;
    }

    public void setDongia(int dongia) {
        this.dongia = dongia;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }
}
