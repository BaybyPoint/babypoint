package com.minhhieu.carinterior.model.response.user_profile;

import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Immutable
public class UserProfileResNoPass {
    @Id
    private int iduser;

    private String username, email,address, avatar ;
    private int idprofile, age ;

    public UserProfileResNoPass() {
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public UserProfileResNoPass(int iduser, String username, String email,int idprofile,  int age, String address, String avatar) {
        this.iduser = iduser;
        this.username = username;
        this.email = email;
        this.address = address;
        this.avatar = avatar;
        this.idprofile = idprofile;
        this.age = age;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public int getIdprofile() {
        return idprofile;
    }

    public void setIdprofile(int idprofile) {
        this.idprofile = idprofile;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
