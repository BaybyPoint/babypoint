package com.minhhieu.carinterior.model.response.user_profile;

import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Immutable // dùng để định nghĩa là entity này chỉ dùng để get chứ ko update hay insert dc
public class UserProfileResponse {
    @Id
    private int iduser;

    private String username, password, email,address, avatar ;
    private int idprofile, age ;

    public UserProfileResponse() {
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public UserProfileResponse(int iduser, String username, String password, String email, String address, String avatar, int idprofile, int age) {
        this.iduser = iduser;
        this.username = username;
        this.password = password;
        this.email = email;
        this.address = address;
        this.avatar = avatar;
        this.idprofile = idprofile;
        this.age = age;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public int getIdprofile() {
        return idprofile;
    }

    public void setIdprofile(int idprofile) {
        this.idprofile = idprofile;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
