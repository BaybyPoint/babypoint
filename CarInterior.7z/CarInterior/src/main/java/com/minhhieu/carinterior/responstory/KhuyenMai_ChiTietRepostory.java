package com.minhhieu.carinterior.responstory;

import com.minhhieu.carinterior.model.request.KhuyenMai_ChiTiet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KhuyenMai_ChiTietRepostory extends JpaRepository<KhuyenMai_ChiTiet, Integer> {

    @Query(nativeQuery = true, value = "select idkhuyenmai,tenkhuyenmai, KHUYENMAI.idchitietkhuyenmai, KHUYENMAI.trangthai, hinhthuc, ngaybatdau, ngayketthuc, CHITIETKHUYENMAI.trangthai , toantu \n" +
            "from KHUYENMAI inner join CHITIETKHUYENMAI on KHUYENMAI.idchitietkhuyenmai = CHITIETKHUYENMAI.idchititetkhuyenmai where KHUYENMAI.trangthai = 1 " )
    List<KhuyenMai_ChiTiet> findAllInformationKhuyenMai();

}
