package com.minhhieu.carinterior.responstory.khuyenmai;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "CHITIETKHUYENMAI")
public class ChiTietKhuyenMaiReponstory {

    @Id
    @GeneratedValue(strategy =  GenerationType.AUTO)
    private int idchitietkhuyenmai ;

    private String hinhthuc, ngaybatdau,ngayketthuc, trangthai, toantu ;

    public ChiTietKhuyenMaiReponstory(String hinhthuc, String ngaybatdau, String ngayketthuc, String trangthai, String toantu) {
        this.hinhthuc = hinhthuc;
        this.ngaybatdau = ngaybatdau;
        this.ngayketthuc = ngayketthuc;
        this.trangthai = trangthai;
        this.toantu = toantu;
    }

    public ChiTietKhuyenMaiReponstory() {
    }

    public int getIdchitietkhuyenmai() {
        return idchitietkhuyenmai;
    }

    public void setIdchitietkhuyenmai(int idchitietkhuyenmai) {
        this.idchitietkhuyenmai = idchitietkhuyenmai;
    }

    public String getHinhthuc() {
        return hinhthuc;
    }

    public void setHinhthuc(String hinhthuc) {
        this.hinhthuc = hinhthuc;
    }

    public String getNgaybatdau() {
        return ngaybatdau;
    }

    public void setNgaybatdau(String ngaybatdau) {
        this.ngaybatdau = ngaybatdau;
    }

    public String getNgayketthuc() {
        return ngayketthuc;
    }

    public void setNgayketthuc(String ngayketthuc) {
        this.ngayketthuc = ngayketthuc;
    }

    public String getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(String trangthai) {
        this.trangthai = trangthai;
    }

    public String getToantu() {
        return toantu;
    }

    public void setToantu(String toantu) {
        this.toantu = toantu;
    }
}
