package com.minhhieu.carinterior.responstory.loaisanpham;

import com.minhhieu.carinterior.model.database.LoaiSanPham;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface LoaiSanPhamRepo extends JpaRepository<LoaiSanPham, Integer> {

    @Query(nativeQuery = true, value = "select * from LOAISANPHAM where tenloaisanpham = :tenloaisanpham")
    LoaiSanPham findLoaiSanPhamByTenloaisanpham(String tenloaisanpham);

    @Query(nativeQuery = true, value = "select * from LOAISANPHAM where trangthai = 1")
    List<LoaiSanPham> findAllLoaiSanPham();

    @Query(nativeQuery = true, value = "INSERT INTO LOAISANPHAM (tenloaisanpham) values (:tenloaisanpham)")
    @Modifying
    @Transactional
    void insertLoaiSanPham(@Param("tenloaisanpham") String tenloaisanpham);

    @Query(nativeQuery = true, value = "UPDATE LOAISANPHAM SET tenloaisanpham = :tenloaisanpham where idloaisanpham = :idloaisanpham ")
    @Modifying
    @Transactional
    void updateLoaiSanPham(@Param("idloaisanpham") int idloaisanpham,@Param("tenloaisanpham") String tenloaisanpham);

    @Query(nativeQuery = true, value = "UPDATE LOAISANPHAM SET trangthai = :trangthai where idloaisanpham = :idloaisanpham")
    @Modifying
    @Transactional
    void deleteLoaiSanPhamFake(@Param("idloaisanpham") int idloaisanpham,@Param("trangthai") int trangthai);
}
