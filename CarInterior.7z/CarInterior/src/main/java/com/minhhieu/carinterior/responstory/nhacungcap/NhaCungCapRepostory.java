package com.minhhieu.carinterior.responstory.nhacungcap;

import com.minhhieu.carinterior.model.database.NhaCungCap;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface NhaCungCapRepostory extends JpaRepository<NhaCungCap, Integer> {

    //@Query(nativeQuery = true, value = "select * from NHACUNGCAP where tenthuonghieu = :tenthuonghieu")
    NhaCungCap findNhaCungCapByTennhacungcap(String tennhacungcap);


}
