package com.minhhieu.carinterior.responstory.profile;

import com.minhhieu.carinterior.model.database.Profile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ProfileResponstory extends JpaRepository<Profile, Integer> {

    @Query(nativeQuery = true, value = "Insert into PROFILE (age, address, avatar) values(:age, :address, :avatar)")
    @Transactional
    @Modifying
    void insertProfile(@Param("age") int age, @Param("address") String address, @Param("avatar") String avatar );




}
