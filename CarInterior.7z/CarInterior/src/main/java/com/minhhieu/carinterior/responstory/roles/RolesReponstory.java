package com.minhhieu.carinterior.responstory.roles;

import com.minhhieu.carinterior.model.database.Roles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RolesReponstory extends JpaRepository<Roles, Integer> {

}
