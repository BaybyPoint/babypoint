package com.minhhieu.carinterior.responstory.sanpham;

import com.minhhieu.carinterior.model.database.SanPham;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface SanPhamRepostory extends JpaRepository<SanPham, Integer> {

    @Transactional
    @Modifying
    @Query(nativeQuery = true, value = "insert into SANPHAM (tensanpham,idloaisanpham, dongia, thongsokithuat, mota, video, soluong, idnhacungcap, idbaohanh, idthuonghieu,idmau,anh, trangthai) " +
            "values (:tensanpham,:idloaisanpham, :dongia, :thongsokithuat, :mota, :video, :soluong, :idnhacungcap, :idbaohanh, :idthuonghieu, :idmau, :anh, 1)")
    void insertSanPham(@Param("tensanpham") String tensanpham,@Param("idloaisanpham") int idloaisanpham,
                          @Param("dongia") int dongia, @Param("thongsokithuat") String thongsokithuat,
                          @Param("mota") String mota, @Param("video") String video, @Param("soluong") int soluong,
                          @Param("idnhacungcap") int idnhacungcap, @Param("idbaohanh") int idbaohanh,
                          @Param("idthuonghieu") int idthuonghieu, @Param("idmau") int idmau, @Param("anh") String anh);

    @Transactional
    @Modifying
    @Query(nativeQuery = true, value = "UPDATE SANPHAM SET " +
            "tensanpham = :tensanpham, idloaisanpham = :idloaisanpham, dongia = :dongia, thongsokithuat = :thongsokithuat," +
            " mota = :mota, video = :video, soluong = :soluong, idnhacungcap = :idnhacungcap, idbaohanh = :idbaohanh," +
            " idthuonghieu = :idthuonghieu, idmau = :idmau, anh = :anh WHERE idsanpham = :idsanpham")
    void updateSanPham(@Param("idsanpham") int idsanpham, @Param("tensanpham") String tensanpham,@Param("idloaisanpham") int idloaisanpham,
                       @Param("dongia") int dongia, @Param("thongsokithuat") String thongsokithuat,
                       @Param("mota") String mota, @Param("video") String video, @Param("soluong") int soluong,
                       @Param("idnhacungcap") int idnhacungcap, @Param("idbaohanh") int idbaohanh,
                       @Param("idthuonghieu") int idthuonghieu, @Param("idmau") int idmau, @Param("anh") String anh);

}
