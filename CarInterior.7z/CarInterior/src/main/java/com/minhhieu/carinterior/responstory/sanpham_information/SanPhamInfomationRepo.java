package com.minhhieu.carinterior.responstory.sanpham_information;

import com.minhhieu.carinterior.model.response.sanpham_information.SanPhamInformation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SanPhamInfomationRepo extends JpaRepository<SanPhamInformation, Integer> {
    @Query(nativeQuery = true, value = "select idsanpham, tensanpham, LOAISANPHAM.tenloaisanpham, dongia, thongsokithuat, mota, video, soluong, \n" +
            "NHACUNGCAP.tennhacungcap, BAOHANH.thoigianbaohanh, THUONGHIEU.tenthuonghieu,MAUSANPHAM.tenmau,anh  from SANPHAM\n" +
            "inner join LOAISANPHAM on SANPHAM.idloaisanpham = LOAISANPHAM.idloaisanpham " +
            "inner join NHACUNGCAP on SANPHAM.idnhacungcap = NHACUNGCAP.idnhacungcap " +
            "inner join BAOHANH on SANPHAM.idbaohanh = BAOHANH.idbaohanh " +
            "inner join THUONGHIEU on SANPHAM.idthuonghieu = THUONGHIEU.idthuonghieu " +
            "inner join MAUSANPHAM on SANPHAM.idmau = MAUSANPHAM.idmau where SANPHAM.trangthai = 1")
    List<SanPhamInformation> findSanPhamInformation();

    @Query(nativeQuery = true, value = "select idsanpham, tensanpham, LOAISANPHAM.tenloaisanpham, dongia, thongsokithuat, mota, video, soluong, \n" +
            "NHACUNGCAP.tennhacungcap, BAOHANH.thoigianbaohanh, THUONGHIEU.tenthuonghieu,MAUSANPHAM.tenmau,anh  from SANPHAM\n" +
            "inner join LOAISANPHAM on SANPHAM.idloaisanpham = LOAISANPHAM.idloaisanpham " +
            "inner join NHACUNGCAP on SANPHAM.idnhacungcap = NHACUNGCAP.idnhacungcap " +
            "inner join BAOHANH on SANPHAM.idbaohanh = BAOHANH.idbaohanh " +
            "inner join THUONGHIEU on SANPHAM.idthuonghieu = THUONGHIEU.idthuonghieu " +
            "inner join MAUSANPHAM on SANPHAM.idmau = MAUSANPHAM.idmau where SANPHAM.trangthai = 0")
    List<SanPhamInformation> findSanPhamInformationDeleted();
}
