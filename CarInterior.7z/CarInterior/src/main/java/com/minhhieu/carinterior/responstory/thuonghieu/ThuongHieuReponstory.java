package com.minhhieu.carinterior.responstory.thuonghieu;

import com.minhhieu.carinterior.model.database.ThuongHieu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ThuongHieuReponstory extends JpaRepository<ThuongHieu, Integer> {

    @Query(nativeQuery = true, value = "SELECT * from THUONGHIEU where tenthuonghieu = :tenthuonghieu ")
    ThuongHieu findThuongHieuByName (@Param("tenthuonghieu") String tenthuonghieu);

    @Transactional
    @Modifying
    @Query(nativeQuery = true, value = "INSERT INTO THUONGHIEU (tenthuonghieu) values (:tenthuonghieu)")
    void insertThuongHieu(@Param("tenthuonghieu") String tenthuonghieu);

}
