package com.minhhieu.carinterior.responstory.user;

import com.minhhieu.carinterior.model.database.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface UsersResponstory extends JpaRepository<Users,Integer> {

//    //Get limit
//    @Query(nativeQuery = true, value = "SELECT * FROM Users " +
//            "order by username " +
//            "OFFSET :start ROWS " +
//            "FETCH NEXT :limit ROWS ONLY")
//    List<Users> findDataLimit(@Param(value = "start") int start, @Param(value = "limit" ) int limit);

    @Query(nativeQuery = true, value = "Select username, password from Users")
    List<Users> getTest();

    @Query(nativeQuery = true, value = "DECLARE @x nvarchar(30); " +
            "set @x = :condition ;" +
            "IF @x = 'username'" +
            " begin " +
            " select * from USERS  " +
            " order by username " +
            " OFFSET :start ROWS " +
            " FETCH NEXT :limit ROWS ONLY " +
            "end " +
            "if @x = 'email' " +
            " begin  " +
            " select * from USERS  " +
            " order by email " +
            " OFFSET :start ROWS " +
            " FETCH NEXT :limit ROWS ONLY " +
            "end ")
    List<Users> findDataLimit(@Param("condition") String condition , @Param(value = "start") int start, @Param(value = "limit" ) int limit);

    @Query(nativeQuery = true, value = "SELECT  id from Users where username = :username ")
    int findIdByName(@Param("username") String username );

    // Insert user
    @Transactional
    @Modifying
    @Query( nativeQuery = true, value = "INSERT INTO Users (username, password, email, idprofile) " +
            "VALUES (:username , :password, :email, :idprofile)")
    void insertUser(@Param(value = "username") String username, @Param(value ="password") String password,
                    @Param(value = "email") String email,@Param(value = "idprofile") int idprofile );

    // find user by email
    @Query(nativeQuery = true, value = "SELECT * from Users where email = :email")
    Users findUsersByEmail(@Param("email") String email);

    // find user by email and username
    @Query(nativeQuery = true, value = "SELECT * from Users where username = :username ")
    Users findUsersByUsername(@Param("username") String username);


}
