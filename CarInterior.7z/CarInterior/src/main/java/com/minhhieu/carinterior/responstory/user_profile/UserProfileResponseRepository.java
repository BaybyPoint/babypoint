package com.minhhieu.carinterior.responstory.user_profile;

import com.minhhieu.carinterior.model.response.user_profile.UserProfileResNoPass;
import com.minhhieu.carinterior.model.response.user_profile.UserProfileResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserProfileResponseRepository extends JpaRepository<UserProfileResponse, Integer> {
    @Query(nativeQuery = true, value = "select iduser , username, password, email, USERS.idprofile, age, address, avatar from USERS join PROFILE " +
            "on USERS.idprofile =  PROFILE.idprofile " +
            "where iduser = :user_id ")
    UserProfileResponse findUserProfileByIdUser(@Param(value = "user_id") int user_id);

}
