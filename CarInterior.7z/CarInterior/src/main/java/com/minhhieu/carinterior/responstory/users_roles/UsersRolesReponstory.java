package com.minhhieu.carinterior.responstory.users_roles;

import com.minhhieu.carinterior.model.database.UsersRoles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UsersRolesReponstory extends JpaRepository<UsersRoles, Integer> {
    @Query (nativeQuery = true, value = "SELECT * FROM USERS_ROLES WHERE iduser = :iduser and idrole = :idrole")
    UsersRoles findUserRolesByIduserAndIdrole(@Param("iduser") int iduser, @Param("idrole") int idrole);
}
