package com.minhhieu.carinterior.service.khuyenmai;

import com.minhhieu.carinterior.model.database.KhuyenMai;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.responstory.khuyenmai.KhuyenMaiReponstory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KhuyenMaiSerImp implements KhuyenMaiService {

    @Autowired
    private KhuyenMaiReponstory kMaiRepo ;

    @Override
    public List<KhuyenMai> getAllDataKhuyenMai() {
        return kMaiRepo.findAll();
    }

    @Override
    public ResponseEntity<ErrorTemplate> createNewKhuyenMai(KhuyenMai khuyenMai) {
        kMaiRepo.save(khuyenMai) ;
        return new ResponseEntity<>(new ErrorTemplate(200, "Thành công", "Đã tạo thành công bản ghi !") ,HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ErrorTemplate> setKhuyenMai(KhuyenMai khuyenMai) {
        kMaiRepo.save(khuyenMai) ;
        return new ResponseEntity<>(new ErrorTemplate(200, "Thành công", "Đã sửa thành công bản ghi !") ,HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ErrorTemplate> deleteKhuyenMai(int idkhuyenmai) {
        kMaiRepo.deleteById(idkhuyenmai);
        return new ResponseEntity<>(new ErrorTemplate(200, "Thành công", "Đã xóa thành công bản ghi !") ,HttpStatus.OK);
    }


}
