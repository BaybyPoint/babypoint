package com.minhhieu.carinterior.service.khuyenmai;

import com.minhhieu.carinterior.model.database.ChiTietKhuyenMai;
import com.minhhieu.carinterior.model.database.KhuyenMai;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface KhuyenMaiService {
    List<KhuyenMai> getAllDataKhuyenMai();
    ResponseEntity<ErrorTemplate> createNewKhuyenMai(KhuyenMai khuyenMai);
    ResponseEntity<ErrorTemplate> setKhuyenMai(KhuyenMai khuyenMai);
    ResponseEntity<ErrorTemplate> deleteKhuyenMai(int idkhuyenmai );
}
