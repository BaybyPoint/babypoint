package com.minhhieu.carinterior.service.khuyenmai_chitiet;

import com.minhhieu.carinterior.model.request.KhuyenMai_ChiTiet;

import java.util.List;

public interface KhuyenMai_ChitietSer {
    List<KhuyenMai_ChiTiet> getInformationKhuyenMai();
}
