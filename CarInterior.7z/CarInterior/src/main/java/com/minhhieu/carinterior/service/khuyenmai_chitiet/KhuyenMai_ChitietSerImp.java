package com.minhhieu.carinterior.service.khuyenmai_chitiet;

import com.minhhieu.carinterior.model.request.KhuyenMai_ChiTiet;
import com.minhhieu.carinterior.responstory.KhuyenMai_ChiTietRepostory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KhuyenMai_ChitietSerImp implements KhuyenMai_ChitietSer {

    @Autowired
    private KhuyenMai_ChiTietRepostory km_CTRepo ;

    @Override
    public List<KhuyenMai_ChiTiet> getInformationKhuyenMai() {
        return km_CTRepo.findAllInformationKhuyenMai();
    }
}
