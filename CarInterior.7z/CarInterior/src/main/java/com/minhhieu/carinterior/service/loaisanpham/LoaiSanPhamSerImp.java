package com.minhhieu.carinterior.service.loaisanpham;

import com.minhhieu.carinterior.model.database.LoaiSanPham;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.responstory.loaisanpham.LoaiSanPhamRepo;
import net.bytebuddy.asm.Advice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoaiSanPhamSerImp implements LoaiSanPhamService {

    @Autowired
    LoaiSanPhamRepo loaiSPRepo ;

    private boolean checkTenloaisanpham(String tenloaisanpham){
        if(loaiSPRepo.findLoaiSanPhamByTenloaisanpham(tenloaisanpham) == null){
            return false;
        }
        return true;
    }

    private boolean checkIdloaisanpham(int idloaisanpham){
        if(loaiSPRepo.findById(idloaisanpham).orElse(null) == null){
            return false;
        }
        return true;
    }

    @Override
    public List<LoaiSanPham> getAllLoaiSanPham() {
        return loaiSPRepo.findAllLoaiSanPham();
    }

    @Override
    public ResponseEntity<ErrorTemplate> createLoaiSanPham(String tenloaisanpham) {
        if (checkTenloaisanpham(tenloaisanpham)){
            return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !", "Bản ghi đã tồn tại !"),HttpStatus.BAD_REQUEST);
        }else {
            loaiSPRepo.save(new LoaiSanPham(tenloaisanpham.toUpperCase(), 1));
            return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !", "Susscess !"), HttpStatus.OK);
        }
    }

    @Override
    public ResponseEntity<ErrorTemplate> setLoaiSanPham(int idloaisanpham, String tenloaisanpham) {
        if(checkIdloaisanpham(idloaisanpham)){
            if (checkTenloaisanpham(tenloaisanpham)){
                return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !", "Bản ghi đã tồn tại !"),HttpStatus.BAD_REQUEST);
            }else {
                LoaiSanPham lsp = loaiSPRepo.findById(idloaisanpham).orElse(null);
                lsp.setTenloaisanpham(tenloaisanpham.toUpperCase());
                loaiSPRepo.save(lsp);
                return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !", "Susscess !"), HttpStatus.OK);
            }
        }
        return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !", "Không có bản ghi tương ứng, kiểm tra lại !"),HttpStatus.BAD_REQUEST);
    }

    @Override
    public ResponseEntity<ErrorTemplate> removeLoaiSanPhamFake(int idloaisanpham) {
        if(checkIdloaisanpham(idloaisanpham)){
            LoaiSanPham lsp = loaiSPRepo.findById(idloaisanpham).orElse(null);
            lsp.setTrangthai(0);
            loaiSPRepo.save(lsp);
            return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !", "Susscess !"), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !", "Không có bản ghi tương ứng, kiểm tra lại !"),HttpStatus.BAD_REQUEST);
    }

}
