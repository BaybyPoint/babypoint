package com.minhhieu.carinterior.service.loaisanpham;

import com.minhhieu.carinterior.model.database.LoaiSanPham;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface LoaiSanPhamService {
    List<LoaiSanPham> getAllLoaiSanPham();
    ResponseEntity<ErrorTemplate> createLoaiSanPham(String tenloaisanpham);
    ResponseEntity<ErrorTemplate> setLoaiSanPham(int idloaisanpham, String tenloaisanpham);
    ResponseEntity<ErrorTemplate> removeLoaiSanPhamFake(int idloaisanpham);
}
