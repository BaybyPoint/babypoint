package com.minhhieu.carinterior.service.nhacungcap;

import com.minhhieu.carinterior.model.database.NhaCungCap;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface NhaCungCapSer {
    List<NhaCungCap> getAllNhaCungCap();
    ResponseEntity<ErrorTemplate> setNhaCungCap(int idnhacungcap, String tennhacungcap);

}
