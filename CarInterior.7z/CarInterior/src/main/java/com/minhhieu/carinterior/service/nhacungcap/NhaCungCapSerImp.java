package com.minhhieu.carinterior.service.nhacungcap;

import com.minhhieu.carinterior.model.database.NhaCungCap;
import com.minhhieu.carinterior.model.database.ThuongHieu;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.responstory.nhacungcap.NhaCungCapRepostory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NhaCungCapSerImp implements NhaCungCapSer {

    @Autowired
    NhaCungCapRepostory nhaCCRes ;

    @Override
    public List<NhaCungCap> getAllNhaCungCap() {
        return nhaCCRes.findAll();
    }

    private boolean checkTenNhaCungCap(String tennhacungcap){
        if(nhaCCRes.findNhaCungCapByTennhacungcap(tennhacungcap) != null){
            return true;
        }
        return false;
    }

    private boolean checkIdNhaCungCap(int idnhacungcap){
        NhaCungCap ncc = nhaCCRes.findById(idnhacungcap).orElse(null);
        if(ncc != null){
            return true;
        }
        return false;
    }

    @Override
    public ResponseEntity<ErrorTemplate> setNhaCungCap(int idnhacungcap, String tennhacungcap) {
        NhaCungCap ncc = nhaCCRes.findById(idnhacungcap).orElse(null);
        if(ncc != null){
            if(checkTenNhaCungCap(tennhacungcap)){
                return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !",
                        "Nhà cung cấp này đã có trong cơ sở dữ liệu !"),HttpStatus.BAD_REQUEST);
            }else
            {
                ncc.setTennhacungcap(tennhacungcap.toUpperCase());
                nhaCCRes.save(ncc);
                return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !",
                        "Đã sửa nhà cung cấp !"), HttpStatus.OK);
            }
        }
        return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !",
                "Xảy ra lỗi, bản ghi này không có trong cơ sỡ dữ liệu !"),HttpStatus.BAD_REQUEST);
    }
}
