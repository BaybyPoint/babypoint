package com.minhhieu.carinterior.service.profile;

import com.minhhieu.carinterior.model.database.Profile;
import com.minhhieu.carinterior.model.request.UserRegisterRequest;

public interface ProfileService {

    Profile insertProfile(int age, String address, String avatar);
    boolean createUserProfile(int idrole, UserRegisterRequest request );
    boolean setProfile(int idProfile, int age, String address, String avatar);
    boolean setUserProfile(int iduser, String username, String password, String email, int idProfile, int age, String address, String avatar);

}
