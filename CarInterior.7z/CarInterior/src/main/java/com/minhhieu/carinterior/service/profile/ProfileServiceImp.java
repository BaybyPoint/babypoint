package com.minhhieu.carinterior.service.profile;

import com.minhhieu.carinterior.model.database.Profile;
import com.minhhieu.carinterior.model.request.UserRegisterRequest;
import com.minhhieu.carinterior.responstory.profile.ProfileResponstory;
import com.minhhieu.carinterior.service.user.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProfileServiceImp implements ProfileService  {

    @Autowired
    private ProfileResponstory profileResponstory;

    @Autowired
    private UsersService usersService;

    @Override
    public Profile insertProfile(int age, String address, String avatar) {
        Profile profile = new Profile(address, avatar, age);
        return profileResponstory.save(profile);
    }

    @Override
    public boolean createUserProfile(int idrole, UserRegisterRequest request) {
        if(usersService.checkUsernameAndEmail(request.getUsername(), request.getEmail())){
            return false;
        }else{
            Profile profile = insertProfile(request.getAge(), request.getAddress(), request.getAvatar());
            long idProfile = profile.getIdprofile();
            usersService.createUser(idrole, request.getUsername(), request.getPassword(), request.getEmail(),idProfile);
            return true;
        }
    }

    @Override
    public boolean setProfile(int idProfile, int age, String address, String avatar) {
        Profile profile = profileResponstory.findById(idProfile).orElse(null);
        profile.setAge(age);
        profile.setAddress(address);
        profile.setAvatar(avatar);
        profileResponstory.save(profile);
        return true;
    }

    @Override
    public boolean setUserProfile(int iduser, String username, String password, String email, int idProfile, int age, String address, String avatar) {
        if(usersService.setUsers(iduser, username, password, email)){
            setProfile(idProfile, age, address, avatar);
            return true;
        }
        return false;
    }
}



















