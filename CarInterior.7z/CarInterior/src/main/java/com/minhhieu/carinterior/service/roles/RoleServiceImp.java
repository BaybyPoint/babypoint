package com.minhhieu.carinterior.service.roles;

import com.minhhieu.carinterior.model.database.Roles;
import com.minhhieu.carinterior.responstory.roles.RolesReponstory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImp implements RolesService  {

    @Autowired
    RolesReponstory rolesRes;

    @Override
    public List<Roles> getAllDataRoles() {
        return rolesRes.findAll();
    }
}
