package com.minhhieu.carinterior.service.roles;

import com.minhhieu.carinterior.model.database.Roles;
import org.hibernate.validator.constraints.EAN;

import java.util.List;

public interface RolesService {
    List<Roles> getAllDataRoles();
}
