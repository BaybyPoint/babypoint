package com.minhhieu.carinterior.service.sanpham;

import com.minhhieu.carinterior.model.database.SanPham;
import com.minhhieu.carinterior.model.request.SanPhamCreateRequest;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.responstory.sanpham.SanPhamRepostory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class SanPhamSerImp implements SanPhamService {

    @Autowired
    SanPhamRepostory sanPhamRepo ;

    @Override
    public boolean createSanPham(SanPhamCreateRequest request) {
         sanPhamRepo.insertSanPham(request.getTensanpham(), request.getIdloaisanpham(),
                request.getDongia(), request.getThongsokithuat(), request.getMota(),
                request.getVideo(), request.getSoluong(), request.getIdnhacungcap(),
                request.getIdbaohanh(), request.getIdthuonghieu(), request.getIdmau(), request.getAnh());
        return true;
    }

    @Override
    public ResponseEntity<ErrorTemplate> setSanPham(int idsanpham ,SanPhamCreateRequest request) {
        if (checkIdSanPham(idsanpham)){
            sanPhamRepo.updateSanPham(idsanpham, request.getTensanpham(), request.getIdloaisanpham(), request.getDongia(),request.getThongsokithuat(),
                    request.getMota(), request.getVideo(), request.getSoluong(), request.getIdnhacungcap(), request.getIdbaohanh(),
                    request.getIdthuonghieu(), request.getIdmau(),request.getAnh());
            return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !",
                    "Susscess !"), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !",
                "Không tìm thấy phần tử cần xóa trong cơ sở dữ liệu !"),HttpStatus.BAD_REQUEST);

    }

    @Override
    public boolean checkIdSanPham(int idsanpham){
        if(sanPhamRepo.findById(idsanpham).orElse(null) != null){
            return true;
        }
        return false;
    }

    @Override
    public ResponseEntity<ErrorTemplate> deleteSanPhamReal(int idsanpham) {
        if (checkIdSanPham(idsanpham)){
            sanPhamRepo.deleteById(idsanpham);
            return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !", "Susscess !"), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !", "Không tìm thấy phần tử cần xóa trong cơ sở dữ liệu !"),HttpStatus.BAD_REQUEST);
    }

    @Override
    public ResponseEntity<ErrorTemplate> deleteSanPhamFake(int idsanpham) {
        if (checkIdSanPham(idsanpham)){
            SanPham sp = sanPhamRepo.findById(idsanpham).orElse(null);
            sp.setTrangthai(0);
            sanPhamRepo.save(sp);
            return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !", "Susscess !"), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !", "Không tìm thấy phần tử cần xóa trong cơ sở dữ liệu !"),HttpStatus.BAD_REQUEST);
    }

    @Override
    public ResponseEntity<ErrorTemplate> restoreSanPhamFake(int idsanpham) {
        if (checkIdSanPham(idsanpham)){
            SanPham sp = sanPhamRepo.findById(idsanpham).orElse(null);
            sp.setTrangthai(1);
            sanPhamRepo.save(sp);
            return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !", "Susscess !"), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !", "Không tìm thấy phần tử cần xóa trong cơ sở dữ liệu !"),HttpStatus.BAD_REQUEST);
    }
}
