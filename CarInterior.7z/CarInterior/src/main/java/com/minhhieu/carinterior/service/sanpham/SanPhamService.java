package com.minhhieu.carinterior.service.sanpham;

import com.minhhieu.carinterior.model.request.SanPhamCreateRequest;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import org.springframework.http.ResponseEntity;

public interface SanPhamService {
    boolean createSanPham(SanPhamCreateRequest request);
    ResponseEntity<ErrorTemplate> setSanPham(int idsanpham , SanPhamCreateRequest request);
    ResponseEntity<ErrorTemplate> deleteSanPhamReal(int idsanpham);
    ResponseEntity<ErrorTemplate> deleteSanPhamFake(int idsanpham);
    ResponseEntity<ErrorTemplate> restoreSanPhamFake(int idsanpham);
    boolean checkIdSanPham(int idsanpham);
}
