package com.minhhieu.carinterior.service.sanpham_information;

import com.minhhieu.carinterior.model.response.sanpham_information.SanPhamInformation;
import com.minhhieu.carinterior.responstory.sanpham_information.SanPhamInfomationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SanPhamInformationSerImp implements SanPhamInformationService {

    @Autowired
    SanPhamInfomationRepo sanphamIRepo ;

    @Override
    public List<SanPhamInformation> getSanPhamInformation() {
        return sanphamIRepo.findSanPhamInformation();
    }

    @Override
    public List<SanPhamInformation> getSanPhamInformationDeleted() {
        return sanphamIRepo.findSanPhamInformationDeleted();
    }

}
