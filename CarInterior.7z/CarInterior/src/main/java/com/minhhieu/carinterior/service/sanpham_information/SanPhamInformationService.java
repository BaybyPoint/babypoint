package com.minhhieu.carinterior.service.sanpham_information;

import com.minhhieu.carinterior.model.response.sanpham_information.SanPhamInformation;

import java.util.List;

public interface SanPhamInformationService {
    List<SanPhamInformation> getSanPhamInformation();
    List<SanPhamInformation> getSanPhamInformationDeleted();
}
