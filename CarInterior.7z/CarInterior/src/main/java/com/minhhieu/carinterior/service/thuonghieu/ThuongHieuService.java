package com.minhhieu.carinterior.service.thuonghieu;

import com.minhhieu.carinterior.model.database.ThuongHieu;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ThuongHieuService {
    List<ThuongHieu> getAllThuongHieu();
    ResponseEntity<ErrorTemplate> createThuongHieu(String tenthuonghieu);
    ResponseEntity<ErrorTemplate> setThuongHieu(int idthuonghieu,String tenthuonghieu);
    ResponseEntity<ErrorTemplate> removeThuongHieu(int idthuonghieu);
}
