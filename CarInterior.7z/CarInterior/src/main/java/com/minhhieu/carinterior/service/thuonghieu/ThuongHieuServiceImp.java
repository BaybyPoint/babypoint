package com.minhhieu.carinterior.service.thuonghieu;

import com.minhhieu.carinterior.model.database.ThuongHieu;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.responstory.thuonghieu.ThuongHieuReponstory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ThuongHieuServiceImp implements ThuongHieuService{

    @Autowired
    ThuongHieuReponstory thuongHieuRes ;

    @Override
    public List<ThuongHieu> getAllThuongHieu() {
        return thuongHieuRes.findAll();
    }

    private boolean checkTenThuongHieu(String tenthuonghieu){
        if(thuongHieuRes.findThuongHieuByName(tenthuonghieu.toUpperCase()) != null){
            return true;
        }
        return false;
    }

    @Override
    public ResponseEntity<ErrorTemplate> createThuongHieu(String tenthuonghieu) {
        if(checkTenThuongHieu(tenthuonghieu)){
            return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !",
                    "Thương hiệu này đã có trong cơ sở dữ liệu !"),HttpStatus.BAD_REQUEST);
        }else {
            thuongHieuRes.insertThuongHieu(tenthuonghieu.toUpperCase());
            return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !",
                    "Đã thêm thương hiệu !"), HttpStatus.OK);
        }
    }

    @Override
    public ResponseEntity<ErrorTemplate> setThuongHieu(int idthuonghieu, String tenthuonghieu) {
        ThuongHieu th = thuongHieuRes.findById(idthuonghieu).orElse(null);
        if(th != null){
            if(checkTenThuongHieu(tenthuonghieu)){
                return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !",
                        "Thương hiệu này đã có trong cơ sở dữ liệu !"),HttpStatus.BAD_REQUEST);
            }else
            {
                th.setTenthuonghieu(tenthuonghieu.toUpperCase());
                thuongHieuRes.save(th);
                return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !",
                        "Đã sửa thương hiệu !"), HttpStatus.OK);
            }
        }
        return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !",
                "Xảy ra lỗi, bản ghi này không có trong cơ sỡ dữ liệu !"),HttpStatus.BAD_REQUEST);
    }

    private boolean checkIdThuongHieu(int idthuonghieu){
        ThuongHieu th = thuongHieuRes.findById(idthuonghieu).orElse(null);
        if(th != null){
            return true;
        }
        return false;
    }

    @Override
    public ResponseEntity<ErrorTemplate> removeThuongHieu(int idthuonghieu) {
        if(checkIdThuongHieu(idthuonghieu)){
            thuongHieuRes.deleteById(idthuonghieu);
            return new ResponseEntity<>(new ErrorTemplate(200,"Thành công !",
                    "Đã xóa thương hiệu !"), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ErrorTemplate(404,"Thất bại !",
                "Xảy ra lỗi, bản ghi này không có trong cơ sỡ dữ liệu !"),HttpStatus.BAD_REQUEST);
    }


}
