package com.minhhieu.carinterior.service.user;

import com.minhhieu.carinterior.model.database.Users;
import com.minhhieu.carinterior.model.request.Condition;
import com.minhhieu.carinterior.model.response.PageableResponse;
import com.minhhieu.carinterior.model.response.user_profile.UserProfileResNoPass;

import java.util.List;

public interface UsersService {
    PageableResponse getDataUserLimit(Condition condition, int page, int pagesize);
    List<Users> getAllDataUsers();
    boolean createUser(int idrole, String username, String password, String email, Long idprofile);
    boolean checkUsernameAndEmail(String username, String email);
    boolean setUsers(int iduser, String username, String password, String email);
    UserProfileResNoPass getUserProfile(int iduser);
    boolean checkConditionOrderBy(Condition condition);
    boolean checkLoginUser(String username, String password);
    String getJwp(String username, String password);
    Users loadUserByUsername(String username);
    boolean deleteUserById(int id);
}
