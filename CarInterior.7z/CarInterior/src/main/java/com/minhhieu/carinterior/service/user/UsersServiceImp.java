package com.minhhieu.carinterior.service.user;

import com.minhhieu.carinterior.model.database.Users;
import com.minhhieu.carinterior.model.request.Condition;
import com.minhhieu.carinterior.model.response.PageableResponse;
import com.minhhieu.carinterior.model.response.user_profile.UserProfileResNoPass;
import com.minhhieu.carinterior.responstory.profile.ProfileResponstory;
import com.minhhieu.carinterior.responstory.user.UsersResponstory;
import com.minhhieu.carinterior.responstory.user_profile.UserProfileNoPassResponseReponsity;
import com.minhhieu.carinterior.responstory.user_profile.UserProfileResponseRepository;
import com.minhhieu.carinterior.responstory.users_roles.UsersRolesReponstory;
import com.minhhieu.carinterior.service.jwt.JwtService;
import com.minhhieu.carinterior.service.users_roles.UsersRolesSer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsersServiceImp implements UsersService {

    @Autowired
    private UsersResponstory usersResponstory;

    @Autowired
    private ProfileResponstory profileResponstory;

    @Autowired
    private UserProfileResponseRepository userProfile;

    @Autowired
    private UserProfileNoPassResponseReponsity userProfileNoPass;

    @Autowired
    JwtService jwtService;

    @Autowired
    UsersRolesSer userRoleSer;

    public boolean checkUsernameAndEmail(String username, String email){
//        List<Users> lstUser = usersResponstory.findAll();
//        boolean bo = false;
//        for (Users u : lstUser){
//            if( u.getUsername().equals(username) || u.getEmail().equals(email)) {
//                bo = true ;
//                break;
//            }
//        }
//        return bo;
        Users us1 = usersResponstory.findUsersByUsername(username);
        Users us2 = usersResponstory.findUsersByEmail(email);
        if(us1 == null && us2 == null){
            return false;
        }else{
            return true;
        }
    }

    @Override
    public boolean setUsers(int iduser, String username, String password, String email) {
        Users users = usersResponstory.findById(iduser).orElse(null);
        users.setUsername(username);
        users.setPassword(password);
        users.setEmail(email);
        usersResponstory.save(users);
        return true;
    }

    @Override
    public UserProfileResNoPass getUserProfile(int iduser) {
        return userProfileNoPass.findUserProfileByIdUserNoPassword(iduser);
    }

    @Override
    public boolean checkConditionOrderBy(Condition condition){
        Condition[] all = Condition.values();
        for (Condition c : all){
            if(condition == c){
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean checkLoginUser(String username, String password) {
        Users u = usersResponstory.findUsersByUsername(username);
        if(u == null){
            return false;
        }else {
            if(u.getPassword().equals(password)){
                return true;
            }
            return false;
        }
    }

    @Override
    public String getJwp(String username, String password) {
        String result = "";
        //HttpStatus httpStatus = null;
        try {
            if (checkLoginUser(username, password)) {
                result = jwtService.generateTokenLogin(username);
                //httpStatus = HttpStatus.OK;
            } else {
                result = "Wrong userId and password";
                //httpStatus = HttpStatus.BAD_REQUEST;
            }
        } catch (Exception ex) {
            result = "Server Error";
            //httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return result;
    }

    public Users loadUserByUsername(String username) {
        for (Users user : getAllDataUsers()) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    @Override
    public boolean deleteUserById(int id) {
        usersResponstory.delete(usersResponstory.findById(id).orElse(null));
        return true;
    }

    @Override
    public PageableResponse getDataUserLimit(Condition condition , int page, int pagesize) {
        List<Users> lstUsers ;
        double totalpage = 0;
        if(checkConditionOrderBy(condition)){
            if(page > 0 && pagesize > 0 ){
                int start = (page - 1)*pagesize ;
                totalpage = Math.ceil( (double) usersResponstory.findAll().size()/pagesize) ;
                lstUsers = usersResponstory.findDataLimit(condition.toString(), start, pagesize);
            }else {
                lstUsers = null;
            }
        }else {
            lstUsers = null;
        }
        PageableResponse pageableResponse = new PageableResponse(pagesize, page, totalpage, lstUsers);
        return pageableResponse;
    }

    @Override
    public List<Users> getAllDataUsers() {
        return usersResponstory.findAll();
    }

    @Override
    public boolean createUser(int idrole,String username, String password, String email, Long idprofile) {
        if (checkUsernameAndEmail(username, email) == false){
            Users u = usersResponstory.save(new Users(username, password, email, idprofile));
            userRoleSer.createUserRole(u.getIduser(),idrole);
            return true;
        }
        return false;
    }

}
