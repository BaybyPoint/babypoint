package com.minhhieu.carinterior.service.userprofile;

import com.minhhieu.carinterior.model.response.user_profile.UserProfileResNoPass;

public interface UserProfileResNoPassService {
    UserProfileResNoPass findOneUserProfileResNoPass(int iduser);
}
