package com.minhhieu.carinterior.service.userprofile;

import com.minhhieu.carinterior.model.response.user_profile.UserProfileResNoPass;
import com.minhhieu.carinterior.responstory.user_profile.UserProfileNoPassResponseReponsity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserProfileResNoPassServiceImp implements UserProfileResNoPassService {

    @Autowired
    private UserProfileNoPassResponseReponsity UPNoPassRes;

    @Override
    public UserProfileResNoPass findOneUserProfileResNoPass(int iduser) {
        return UPNoPassRes.findUserProfileByIdUserNoPassword(iduser);
    }
}
