package com.minhhieu.carinterior.service.userprofile;

import com.minhhieu.carinterior.model.response.user_profile.UserProfileResponse;

public interface UserProfileService {
    UserProfileResponse getUserProfileResponse(int id_user);
}
