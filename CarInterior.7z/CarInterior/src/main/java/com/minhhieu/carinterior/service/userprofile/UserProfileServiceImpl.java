package com.minhhieu.carinterior.service.userprofile;

import com.minhhieu.carinterior.model.response.user_profile.UserProfileResponse;
import com.minhhieu.carinterior.responstory.user_profile.UserProfileResponseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserProfileServiceImpl implements UserProfileService {

    @Autowired
    private UserProfileResponseRepository userProfileResponseRepository;

    @Override
    public UserProfileResponse getUserProfileResponse(int id_user) {
        return userProfileResponseRepository.findUserProfileByIdUser(id_user);
    }
}
