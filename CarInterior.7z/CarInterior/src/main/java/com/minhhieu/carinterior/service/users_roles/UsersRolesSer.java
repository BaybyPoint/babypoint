package com.minhhieu.carinterior.service.users_roles;

import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import org.springframework.http.ResponseEntity;

public interface UsersRolesSer {
    void createUserRole(int iduser, int idrole);
}
