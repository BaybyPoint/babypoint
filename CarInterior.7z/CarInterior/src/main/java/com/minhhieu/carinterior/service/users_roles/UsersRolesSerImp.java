package com.minhhieu.carinterior.service.users_roles;

import com.minhhieu.carinterior.model.database.UsersRoles;
import com.minhhieu.carinterior.model.response.errors.ErrorTemplate;
import com.minhhieu.carinterior.responstory.users_roles.UsersRolesReponstory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class UsersRolesSerImp implements UsersRolesSer {

    @Autowired
    UsersRolesReponstory userRoleRes;

    @Override
    public void createUserRole(int iduser, int idrole) {
        if(checkIdUserRole(iduser, idrole)){

        }
        else {
            userRoleRes.save( new UsersRoles(iduser, idrole));
        }

    }

    private boolean checkIdUserRole(int iduser , int idrole){
        if(userRoleRes.findUserRolesByIduserAndIdrole(iduser, idrole) == null){
            return false ;
        }
        return true;
    }
}
